local cpu=manager.machine.devices[":maincpu"]
local frame=0
local f=assert(io.open("freeplay-write.csv","w"));f:write("frame,pc,offset,data,mask,ar0,ar1,ar2,sp\n")
local tap=cpu.spaces.program:install_write_tap(0x9c0000,0x9c1fff,"freeplay-audit",function(offset,data,mask)
 if offset==0x9c0073 then f:write(string.format("%d,%X,%X,%X,%X,%X,%X,%X,%X\n",frame,cpu.state.PC.value,offset,data,mask,cpu.state.AR0.value,cpu.state.AR1.value,cpu.state.AR2.value,cpu.state.SP.value));f:flush() end
end)
return function(n) frame=n;assert(tap); if n==1 then print("freeplay at frame1 "..cpu.spaces.program:read_u32(0x9c0073)) end end
