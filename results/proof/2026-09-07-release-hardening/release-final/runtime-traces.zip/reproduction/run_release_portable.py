import json,subprocess,sys
from pathlib import Path
sys.path.insert(0,'harness')
from verification import write_json,sha256_file
from release_identity import source_identity
import run_regressions,check_fresh_boots,check_menu,release_gate
root=Path(sys.argv[2]).resolve();root.mkdir()
package=Path(sys.argv[1]).resolve();candidate=Path('E:/Source/mame-src/vunit.exe')
report={'physical_force':False,'candidate_sha256':sha256_file(candidate),'source_identity':source_identity(Path.cwd())['sha256'],'package_sha256':sha256_file(package),'stages':{}}
def stage(name,fn):
    print('BEGIN',name,flush=True);code=fn();report['stages'][name]=code;write_json(root/'report.json',report);print('END',name,code,flush=True);return code
stage('frozen',lambda:subprocess.call([sys.executable,'-u','harness/check_frozen_package.py',str(package),'--candidate',str(candidate),'--rom-source','E:/Source/launchbox/Launchbox-Racing/Emulators/mame286/roms','--output',str(root/'frozen')]))
stage('regressions',lambda:run_regressions.main(['--candidate',str(candidate),'--output',str(root/'regressions')]))
stage('fresh-boots',lambda:check_fresh_boots.main(['--candidate',str(candidate),'--output',str(root/'fresh-boots')]))
for name,path in [('usa','usa-widescreen-candidate-case'),('world','world-germany-20260906'),('offroad','six-final-offroad/case')]:
    stage('menu-'+name,lambda name=name,path=path:check_menu.main(['results/diagnostics/'+path,'--candidate',str(candidate),'--output',str(root/('menu-'+name))]))
stage('quality',lambda:subprocess.call([sys.executable,'harness/verify_quality.py','--report',str(root/'quality.json')]))
for case in ['capture','capture-8000']:
    stage('exact-'+case,lambda case=case:subprocess.call([sys.executable,'gpu/renderer.py','results/'+case]))
stage('gate',lambda:release_gate.main(['--candidate',str(candidate),'--regressions',str(root/'regressions/report.json'),'--fresh-boots',str(root/'fresh-boots/report.json'),'--init-attended',str(root/'attended.json'),'--report',str(root/'readiness.json')]))
report['automated_stages_pass']=all(code==0 for name,code in report['stages'].items() if name!='gate');write_json(root/'report.json',report)
print(json.dumps(report,indent=2),flush=True)

if report['automated_stages_pass'] and json.loads((root/'readiness.json').read_text())['automated_pass']:
    stage('actual-zip-upgrade',lambda:subprocess.call([sys.executable,'-u','results/diagnostics/startup-work/check_upgrade_package_receipt.py',str(package),str(root/'upgrade')]))
report['automated_stages_pass']=all(code==0 for name,code in report['stages'].items() if name!='gate')
report['source_unchanged']=source_identity(Path.cwd())['sha256']==report['source_identity']
report['binary_unchanged']=sha256_file(candidate)==report['candidate_sha256']
report['package_unchanged']=sha256_file(package)==report['package_sha256']
write_json(root/'report.json',report)
print(json.dumps(report,indent=2),flush=True)
