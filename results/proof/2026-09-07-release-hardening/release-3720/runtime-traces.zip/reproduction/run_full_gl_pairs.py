import json,subprocess,sys
from pathlib import Path
sys.path.insert(0,'harness')
import replay
from gl_frames import compare_completed_frames,requested_frames
from verification import write_json,sha256_file
candidate=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
old=Path('results/diagnostics/release-pre-startup/binary/vunit.exe').resolve()
report={'physical_force':False,'reference_binary':sha256_file(old),'candidate_binary':sha256_file(candidate),'cases':[]}
for name,case,first,last,height in [('usa','usa-widescreen-candidate-case',600,4800,400),('world','world-germany-extended-20260906',1000,8700,400),('offroad','six-final-offroad/case',600,5800,401)]:
    row={'name':name,'first':first,'last':last,'height':height,'runs':[]}
    for label,exe in [('old',old),('new',candidate)]:
        work=out/f'{name}-{label}'
        code=replay.main(['results/diagnostics/'+case,'--candidate',str(exe),'--output',str(work),'--small-window','--gl-scale','4','--gl-crt','on','--gl-height',str(height),'--gl-capture',f'{first}:{last}','--gl-every','100','--gl-max','100','--timeout','300','--gl-log'])
        row['runs'].append({'label':label,'exit':code,'report':str(work/'report.json')});print(name,label,code,flush=True)
    try:row['comparison']=compare_completed_frames(out/f'{name}-old/run/gl-snap',out/f'{name}-new/run/gl-snap',requested_frames(first,last,100))
    except Exception as error:row['comparison']={'passed':False,'error':str(error)}
    row['passed']=all(x['exit']==0 for x in row['runs']) and row['comparison']['passed'];report['cases'].append(row);write_json(out/'report.json',report)
    print(name,'full paired graphics',row['passed'],flush=True)
report['passed']=all(row['passed'] for row in report['cases']);write_json(out/'report.json',report)
