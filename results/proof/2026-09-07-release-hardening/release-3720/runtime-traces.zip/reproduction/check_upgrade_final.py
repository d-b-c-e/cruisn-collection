import hashlib,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
from unittest import mock
sys.path.insert(0,'harness')
import updater
from verification import sha256_file,write_json
root=Path('results/diagnostics/release-upgrade-final').resolve();root.mkdir()
app=root/"Player's upgrade install";app.mkdir()
package=Path('build/CruisnCollection-v0.4.0-rc1-20260907-042637.zip').resolve()
preserved={'rig/collection.ini':b'[collection]\nffb=37\ncrt=1\n','rig/nvram/crusnusa/nvram':b'preserve current scores and calibration','rig/cfg/crusnusa.cfg':b'preserve current bindings','roms/owned-test-marker.txt':b'owned ROM directory marker, no ROM content'}
for name,data in preserved.items():p=app/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(app/'version.txt').write_text('v0.3.7')
# Historical input proxy is used only as migration bytes. No historical
# executable/plugin is run, and relaunch is explicitly disabled.
proxy=Path('E:/Source/mame-src/_plugin-backup-boomslangnz-2.0.0.53/dinput8.dll')
shutil.copy2(proxy,app/'dinput8.dll');before=sha256_file(proxy)
with mock.patch.object(updater,'frozen',return_value=True),mock.patch.object(updater,'app_dir',return_value=str(app)),mock.patch.object(updater.run_rig,'POC',str(app)):
    with mock.patch.object(updater.subprocess,'Popen') as launch:
        script=updater.apply(str(package),relaunch=False)
        command=launch.call_args.args[0];env=launch.call_args.kwargs['env']
    with (root/'helper.stdout.log').open('wb') as stdout,(root/'helper.stderr.log').open('wb') as stderr:
        result=subprocess.run(command,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
report={'passed':False,'physical_force':False,'scope':'Actual candidate ZIP through real PowerShell update helper, relaunch disabled. Isolated existing-state fixture plus actual historical DLL bytes; no emulator or old plugin executed. Not attended upgrade or rollback acceptance.','package_sha256':sha256_file(package),'helper_exit':result.returncode,'preserved':{},'file_hashes':{},'errors':[]}
for name,data in preserved.items():report['preserved'][name]=(app/name).read_bytes()==data
with zipfile.ZipFile(package) as z:
    for entry in z.infolist():
        if entry.is_dir():continue
        parts=Path(entry.filename).parts;name=Path(*parts[1:]).as_posix()
        expected=hashlib.sha256(z.read(entry)).hexdigest();actual=sha256_file(app/name) if (app/name).exists() else None
        report['file_hashes'][name]=actual
        if actual!=expected:report['errors'].append(name)
backups=list((app/'rig/update').glob('retired-input-*/dinput8.dll'))
report['legacy_backup']={'count':len(backups),'original_sha256':before,'sha256':sha256_file(backups[0]) if len(backups)==1 else None,'active_proxy_absent':not (app/'dinput8.dll').exists()}
report['passed']=result.returncode==0 and all(report['preserved'].values()) and not report['errors'] and len(backups)==1 and sha256_file(backups[0])==before and not (app/'dinput8.dll').exists()
shutil.copy2(app/'rig/update/apply.log',root/'apply.log');shutil.copy2(script,root/'apply.ps1')
write_json(root/'report.json',report);print('Actual ZIP upgrade',report['passed'],len(report['file_hashes']),'files',flush=True);raise SystemExit(not report['passed'])
