-- Read-only Off Road 1.63 culler/table/camera/ADC profile; explicit limits only.
local cpu=manager.machine.devices[':maincpu'];local s=cpu.spaces.program
assert(manager.machine.system.name=='offroadc','Off Road1.63 only')
local first=tonumber(os.getenv('CRUISN_OFFROAD_FIRST') or '1800')
local last=tonumber(os.getenv('CRUISN_OFFROAD_LAST') or '5990')
assert(first and last and first%1==0 and last%1==0 and first>=1 and last>first and last-first<=12000)
local frame,taps,out,tableout,camera,adc,failed,limit=0,{},nil,nil,nil,nil,nil,nil
local far_tests,stock_rejects,rejects,extra=0,0,0,0
local consumers={}
local base=0xcb0fc8
local function regfloat(name)
 return string.unpack('<f',string.pack('<I4',cpu.state[name].value&0xffffffff))
end
local function flush()
 if not out then return end
 assert(out:write(string.format('%d,%d,%d,%d,%d,%d\n',frame,limit,far_tests,stock_rejects,rejects,extra)))
 local pcs={};for pc in pairs(consumers) do pcs[#pcs+1]=pc end;table.sort(pcs)
 for _,pc in ipairs(pcs) do
  local v=consumers[pc]
  assert(tableout:write(string.format('%d,%x,%08x,%d,%d,%d,%d\n',frame,pc,s:read_u32(pc-1),v.n,v.lo,v.hi,v.clamped)))
 end
 far_tests,stock_rejects,rejects,extra=0,0,0,0;consumers={}
end
local function close()
 for _,t in ipairs(taps) do t:remove() end;taps={}
 for _,f in ipairs({out,tableout,camera,adc}) do if f then f:close() end end
 out,tableout,camera,adc=nil,nil,nil,nil
end
cruisn_offroad_distance_stop=emu.add_machine_stop_notifier(close)
local function tap(a,b,name,callback)
 taps[#taps+1]=s:install_read_tap(a,b,name,function(o,d,m)
  if failed then return end
  local ok,reason=pcall(callback,o,d,m);if not ok then failed=tostring(reason) end
  -- No replacement return value: the explicit checked patch owns any trial.
 end)
end
return function(n)
 assert(not failed,failed)
 if out then flush() end
 frame=n
 if n==first then
  for _,w in ipairs({{0x1c35,0x0420b724},{0x1c36,0x6a2a066c},{0x1c42,0x04b111a8},
      {0x1c43,0x54b111a8},{0x1c44,0x0a414000},{0x111a7,base},{0x111a8,63679},
      {0x1820,0x07201221},{0x1821,0x1420b724},{0x11223,0x0f78c000},
      {0x1b725,0x0f78c000},{0x1bfc,0x082f120b},{0x1120b,0x196f3}}) do
   assert(s:read_u32(w[1])==w[2],string.format('Off Road profile mismatch at%x',w[1]))
  end
  local word=s:read_u32(0x11221)
  assert(word==0x0f38c000 or word==0x0f66f000,'unsupported Off Road far trial')
  assert(s:read_u32(0x1b724)==word,'Off Road initial far did not reach active culler')
  limit=word==0x0f38c000 and 47296 or 59120
  out=assert(io.open('offroad-distance.csv','w'));out:setvbuf('full',65536)
  out:write('frame,far,far_tests,stock_rejects,far_rejects,extra_admissions\n')
  tableout=assert(io.open('offroad-projection.csv','w'));tableout:setvbuf('full',65536)
  tableout:write('frame,pc,opcode,reads,minimum_index,maximum_index,upper_clamps\n')
  camera=assert(io.open('offroad-camera.csv','w'));camera:setvbuf('full',65536)
  camera:write('frame,x,y,z,m0,m1,m2,m3,m4,m5,m6,m7,m8\n')
  adc=assert(io.open('offroad-adc.csv','w'));adc:setvbuf('full',65536)
  adc:write('frame,time,pc,value\n')
  tap(0x1b724,0x1b724,'offroad_far',function(o,d)
   if cpu.state.PC.value~=0x1c36 then return end
   assert(d==word,'Off Road far changed during observation')
   local depth=regfloat('R0F')
   assert(depth==depth and math.abs(depth)<math.huge,'invalid culler depth')
   far_tests=far_tests+1
   if depth>=47296 then stock_rejects=stock_rejects+1 end
   if depth>=limit then rejects=rejects+1 elseif depth>=47296 then extra=extra+1 end
  end)
  tap(base-4096,base+63679,'offroad_all_projection',function(o,d)
   local pc=cpu.state.PC.value;assert(pc>0 and pc<0x20000,'unexpected table caller')
   local i=o-base;local v=consumers[pc] or {n=0,lo=i,hi=i,clamped=0};consumers[pc]=v
   v.n=v.n+1;v.lo=math.min(v.lo,i);v.hi=math.max(v.hi,i)
   if i==63679 then v.clamped=v.clamped+1 end
  end)
  tap(0x993000,0x993000,'offroad_actual_adc',function(o,d)
   assert(adc:write(string.format('%d,%.12f,%x,%x\n',frame,emu.time(),cpu.state.PC.value,d)))
  end)
 end
 if camera and n<=last then
  assert(s:read_u32(0x1120b)==0x196f3,'camera matrix pointer changed')
  assert(camera:write(n))
  for _,i in ipairs({3,7,11,0,1,2,4,5,6,8,9,10}) do assert(camera:write(string.format(',%08x',s:read_u32(0x196f3+i)))) end
  assert(camera:write('\n'))
 end
 if n==last+1 then close() end
end
