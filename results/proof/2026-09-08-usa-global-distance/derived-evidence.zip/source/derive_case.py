"""Record an explicit candidate case from an existing drive, preserving its source.

New game code can intentionally change pictures and subsequent game history.
This creates a separate reference, checks effective inputs against its parent,
and then requires identity replay. It never replaces or blesses the parent.
"""
import argparse
import json
from pathlib import Path
import sys

from diagnostic_runtime import diagnostic_env, execute, new_run
from game_patch import read_patch
from gl_frames import read_completed_frames, requested_frames
from session_case import Recording, compare_evidence, session_evidence, tree_hashes
from session_clock import SessionClock
from verification import sha256_file, write_json
import replay
import world_distance
import usa_distance


def configure_gl(settings, rom, interval, every, stop):
    if interval is None:
        return None
    first,last = map(int,interval.split(':'))
    if not 0 <= first < last < stop-1:
        raise ValueError('GL interval must leave a completed frame before the recording stops')
    frames = list(requested_frames(first,last,every))
    key = 'MIDZ' if rom=='crusnexo' else 'MIDV'
    if settings.get(key+'_GL')!='1':
        raise ValueError('GL capture requires the recorded game renderer')
    settings.update({key+'_GL_'+k:v for k,v in dict(SNAP='redirect-at-launch',
        SNAP_FIRST=str(first),SNAP_LAST=str(last),SNAP_EVERY=str(every),SNAP_MAX=str(len(frames))).items()})
    return frames


def validate_parent(case, manifest):
    if manifest.get('schema') != 1 or manifest.get('status') != 'recorded':
        raise ValueError('parent must be a completed schema-1 case')
    if tree_hashes(case / 'initial') != manifest['initial_hashes']:
        raise ValueError('parent initial state changed')
    if sha256_file(case / 'record/input/session.inp') != manifest['inp_sha256']:
        raise ValueError('parent INP changed')
    for path, digest in manifest['rom_containers'].items():
        if sha256_file(path) != digest:
            raise ValueError('parent ROM dependency changed')
    if session_evidence(case / 'record', manifest['every'], manifest['returncode']) != manifest['evidence']:
        raise ValueError('parent evidence changed')


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('parent', type=Path)
    ap.add_argument('--candidate', type=Path, required=True)
    ap.add_argument('--patch', type=Path, required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--title', required=True)
    ap.add_argument('--scenery', choices=('off', 'mountains', 'trees', 'all'),
                    help='archive an explicit native scenery setting in the derived case')
    ap.add_argument('--scenery-lead', type=int, choices=range(9),
                    help='archive native background activation lead; 0 disables earlier activation')
    ap.add_argument('--clock', action='store_true', help='show the external emulation clock in both runs')
    ap.add_argument('--timeout', type=float, default=300)
    ap.add_argument('--gl-capture', help='FIRST:LAST completed GL frames, verified in both candidate runs')
    ap.add_argument('--gl-every', type=int, default=60)
    world_distance.add_arguments(ap)
    usa_distance.add_arguments(ap)
    args = ap.parse_args(argv)
    if args.timeout <= 0: ap.error('timeout must be positive')
    work = new_run('derived-case', args.output)
    report = {'schema': 1, 'passed': False, 'physical_force': False,
              'original_route_equivalence': 'not established by derivation or identity replay',
              'scope': 'new candidate repeatability; parent visual differences retained'}
    try:
        parent = args.parent.resolve()
        manifest = json.loads((parent / 'case.json').read_text(encoding='utf-8'))
        validate_parent(parent, manifest)
        read_patch(args.patch)
        command = [str(args.candidate.resolve()), *manifest['command'][1:]]
        settings = dict(manifest['settings'])
        settings['MIDV_PATCH'] = str(args.patch.resolve())
        if args.scenery is not None:
            settings.update(MIDV_SCENERY=args.scenery, MIDV_SCENERY_LOG='1')
        if args.scenery_lead is not None:
            settings.update(MIDV_SCENERY_LEAD=str(args.scenery_lead), MIDV_SCENERY_LOG='1')
        trial = world_distance.configure(args, manifest['rom'], settings)
        if trial:
            settings['MIDV_PATCH'] = str(world_distance.compose(args.patch, work/'global-distance-patch.txt', trial['far']))
            report['world_distance'] = trial
        usa_trial = usa_distance.configure(args, manifest['rom'], settings)
        if usa_trial:
            settings['MIDV_PATCH'] = str(usa_distance.compose(args.patch, work/'usa-distance-patch.txt', usa_trial['far']))
            report['usa_distance'] = usa_trial
        expected_gl = configure_gl(settings,manifest['rom'],args.gl_capture,args.gl_every,manifest['evidence']['frames'])
        env = diagnostic_env(settings)
        recording = Recording(work / 'case', every=manifest['every'],
                              stop_frame=manifest['evidence']['frames'], snapshot_mode='raw', clock=args.clock)
        cmd, run_env, runtime = recording.prepare(command, env, parent / 'initial',
                                                  stimulus=parent / 'record/input/session.inp')
        recording.manifest.update(title=args.title, derived_from={
            'case': str(parent), 'case_sha256': sha256_file(parent / 'case.json'),
            'inp_sha256': manifest['inp_sha256'], 'change': 'explicit candidate executable and game patch'})
        write_json(recording.path / 'case.json', recording.manifest)
        clock = SessionClock(runtime, args.title)
        if args.clock: clock.start()
        try:
            invocation = execute(cmd, runtime, run_env, args.timeout)
        finally:
            clock.close()
        (runtime / 'launch.log').write_bytes((runtime / 'stdout.log').read_bytes())
        recording.finish(invocation['returncode'])
        if invocation['error'] or recording.manifest['status'] != 'recorded':
            raise ValueError(invocation['error'] or recording.manifest.get('error'))
        if expected_gl:
            read_completed_frames(runtime/'gl-snap',expected_gl)
            report['expected_gl_frames']=expected_gl
        comparison = compare_evidence(parent / 'record', runtime, manifest['evidence'],
                                      recording.manifest['evidence'])
        report['parent_comparison'] = comparison
        if comparison['input_or_time_mismatches']:
            raise ValueError('derived recording changed effective input or emulated time')
        report['identity_replay_passed'] = replay.main([
            str(recording.path), '--output', str(work / 'replay'), '--timeout', str(args.timeout),
            *(['--compare-gl'] if expected_gl else []),
            *(['--clock'] if args.clock else [])]) == 0
        report['passed'] = report['identity_replay_passed']
    except (OSError, ValueError, KeyError) as error:
        report['error'] = str(error)
    write_json(work / 'report.json', report)
    print('REPEATABILITY PASS' if report['passed'] else 'FAIL', work / 'report.json')
    print('Original route equivalence is not established; inspect parent differences and motion traces.')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
