"""Optional recheck using the maintainer's Off Road ROM ZIP; no ROM data is emitted."""
import argparse,hashlib,json,math,struct,zipfile
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('rom_zip',type=Path);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
expected=['d0bd40b2cf5d07db9f668826cc7f0ed84c4e84bf','e29926ea24cfbd228a2136d04a63a92eba0098d7','ac72fe205ffb306598400e8b1d9c98ae67b0bab9','2d23b6a2312a75dbaa44de3224512c844aaac7b5']
with zipfile.ZipFile(args.rom_zip) as z:
 lanes=[z.read(f'1.63_off_road_u{i}_game.u{i}') for i in range(10,14)]
assert all(len(v)==0x100000 and hashlib.sha1(v).hexdigest()==h for v,h in zip(lanes,expected))
def raw(i):return sum(lanes[k][0xb0fc8+i]<<(8*k) for k in range(4))
def candidate(i,places):
 numerator,denominator=(1007-i,504) if i<503 else (504,i+1)
 scale=10**places
 q,r=divmod(numerator*scale,denominator)
 if r*2>denominator or (r*2==denominator and q%2):q+=1
 word=struct.unpack('<I',struct.pack('<f',q/scale))[0]
 return ((((word>>23)-127)&255)<<24)|(word&0x7fffff)
trials={str(p):sum(raw(i)!=candidate(i,p) for i in range(63680)) for p in (6,7,8,9)}
negative=sum(raw(i)!=candidate(i,8) for i in range(-4096,0))
r={'formula':'index<503 ? 2-(index+1)/504 : 504/(index+1)',
 'conversion':'exact rational rounding to eight decimal places, ties to even; then float32 and C31',
 'nonnegative_mismatches_by_decimals':trials,'negative_mismatches':negative,
 'table_sha256':hashlib.sha256(b''.join(struct.pack('<I',raw(i)) for i in range(63680))).hexdigest(),
 'source_rom_sha1':expected,'zip_sha256':hashlib.sha256(args.rom_zip.read_bytes()).hexdigest()}
args.output.write_text(json.dumps(r,indent=2),encoding='utf-8')
assert trials['8']==0 and negative==0
print('PASS: all 67776 entries match; other decimal controls disagree')
