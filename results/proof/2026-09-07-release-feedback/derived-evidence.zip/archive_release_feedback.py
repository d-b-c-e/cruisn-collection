"""Archive derived release-feedback evidence; never includes ROM/RAM/NVRAM dumps."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'harness'))
from analyze_drivetrain import analyze
from analyze_force_gate import analyze as analyze_gate
from release_identity import source_identity
from verification import sha256_file, write_json

OUT = ROOT/'results/proof/2026-09-07-release-feedback'
OUT.mkdir(exist_ok=True)
DIAG = ROOT/'results/diagnostics'
SUITE = DIAG/'release-feedback-final-regressions-20260907'
FRESH = DIAG/'release-feedback-fresh-boots-20260907'
FROZEN = DIAG/'release-feedback-frozen-20260907'
PACKAGE = Path(sys.argv[1]).resolve()
manifest = json.loads(Path(str(PACKAGE)+'.manifest.json').read_text())
assert manifest['source_clean']
assert manifest['source_identity'] == source_identity(ROOT)['sha256']
assert manifest['candidate_sha256'] == sha256_file(Path('E:/Source/mame-src/vunit.exe'))
assert manifest['package_sha256'] == sha256_file(PACKAGE)
assert json.loads((SUITE/'report.json').read_text())['passed']
assert json.loads((FRESH/'report.json').read_text())['passed']
assert json.loads((FROZEN/'report.json').read_text())['passed']
files = {}
def add(path, name):
    path = Path(path)
    if not path.is_file(): raise FileNotFoundError(path)
    if name in files: raise ValueError(name)
    files[name] = path
def reports(directory, prefix):
    # JSON reports only; no personal runtime configuration or raw snapshots.
    for path in directory.rglob('report.json'):
        if "Player's clean install" not in path.parts:
            add(path, prefix+'/'+path.relative_to(directory).as_posix())

reports(SUITE, 'regressions')
reports(FRESH, 'fresh-boots')
reports(FROZEN, 'frozen')
names = ('drivetrain.csv','forza.csv','signals.csv','frames.csv','force-source.csv',
         'force-gate.csv','telemetry.jsonl','telemetry-loopback.json','invocation.json',
         'probe.lua','session.lua','game-patch.txt','stdout.log','stderr.log')
plan = json.loads((ROOT/'fixtures/regressions/collection.json').read_text())
accepted = {row['id']:row for row in json.loads((SUITE/'report.json').read_text())['cases']}
checks = []
for case in plan['cases']:
    run = SUITE/case['id']/'run'
    for name in (*names, case['telemetry']['memory']):
        if (run/name).is_file(): add(run/name, f"regressions/{case['id']}/run/{name}")
    telemetry = analyze(run, run/case['telemetry']['memory'])
    expected = dict(accepted[case['id']]['telemetry'])
    assert expected.pop('coverage_passed') is True
    assert telemetry == expected, case['id']
    row = {'id':case['id'], 'telemetry':telemetry}
    if case['telemetry'].get('force_gate_game'):
        row['force_gate'] = analyze_gate(run, run/case['telemetry']['memory'], case['telemetry']['force_gate_game'])
        assert row['force_gate'] == accepted[case['id']]['force_gate'], case['id']
    checks.append(row)

for game in ('usa','world','offroad','exotica'):
    for name in ('invocation.json','launch.log','gl.log'):
        add(FROZEN/game/name, f'frozen/{game}/{name}')
for path in FROZEN.glob('*.png'): add(path, 'frozen/'+path.name)
for suffix in ('.check.json','.manifest.json','.defaults.json'):
    add(str(PACKAGE)+suffix, 'package/package'+suffix)
add(DIAG/'release-feedback-patch-2g3b9i9w/report.json', 'patch/report.json')
add(DIAG/'release-feedback-20260907-tests-final.txt', 'tests/python.txt')
incident = DIAG/'release-feedback-20260907'
add(incident/'manifest.json', 'incident/manifest.json')
for name in ('launch.log','launch.json'):
    add(incident/'launch-history/20260907T204447856890Z'/name, 'incident/new-york-3x/'+name)
for name in ('analyze_drivetrain.py','analyze_force_gate.py','verification.py','analyze_session.py'):
    add(ROOT/'harness'/name, 'analyzers/'+name)
add(ROOT/'fixtures/regressions/collection.json', 'analyzers/suite.json')
add(Path(__file__), 'archive_release_feedback.py')
add(DIAG/'release-feedback-readiness-20260907.json', 'release/readiness.json')
add(DIAG/'release-feedback-attended-20260907.json', 'release/attended-pending.json')
if (DIAG/'release-feedback-ci-20260907/report.json').is_file():
    for path in (DIAG/'release-feedback-ci-20260907').rglob('*.json'):
        add(path, 'ci/'+path.relative_to(DIAG/'release-feedback-ci-20260907').as_posix())

zip_path = OUT/'derived-evidence.zip'
with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name,path in sorted(files.items()): z.write(path,name)
hashes = {name:sha256_file(path) for name,path in sorted(files.items())}
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(hashes)
    assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in hashes.items())
write_json(OUT/'archive.json', {'passed':True, 'scope':__doc__, 'entries':len(files),
    'zip_sha256':sha256_file(zip_path), 'files':hashes, 'source_identity':manifest['source_identity'],
    'candidate_sha256':manifest['candidate_sha256'], 'package_sha256':manifest['package_sha256']})
write_json(OUT/'recomputed.json', {'passed':True,'cases':checks})
for source,target in ((SUITE/'report.json','regressions.json'), (FRESH/'report.json','fresh-boots.json'),
                      (FROZEN/'report.json','frozen.json'), (Path(str(PACKAGE)+'.manifest.json'),'package.manifest.json'),
                      (Path(str(PACKAGE)+'.defaults.json'),'package.defaults.json'),
                      (DIAG/'release-feedback-readiness-20260907.json','readiness.json'),
                      (DIAG/'release-feedback-attended-20260907.json','attended-pending.json')):
    shutil.copyfile(source,OUT/target)
print(json.dumps({'entries':len(files),'bytes':zip_path.stat().st_size,'zip_sha256':sha256_file(zip_path)},indent=2))
